﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindInventoryRecords
{
	//Create a program named FindInventoryRecords that prompts the user for an item number,
	//read the file created in Exercise 2a, and displays data for the specified record.
	class Program
	{
		static void Main(string[] args)
		{
		}
	}
}
