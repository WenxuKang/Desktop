﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindInventoryRecords2
{
	// Create a program named FindInventoryRecord2 that prompts the user for a minimum selling price, reads the file created in Exercise 2a,
	//and displays all the records containing a price greater than or equal to the entered price.

	class Program
	{
		static void Main(string[] args)
		{
		}
	}
}
