﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise_01
{
    class BasePlusCommissionEmployee
    {
        //define variables
        private int employeeId;
        private string firstName;
        private string lastName;
        double baseSalary = 200.00;
        double grossSales;
        double commissionRate = 0.1;

        //properties
        public int EmployeeID
        {
            get
            {
                return employeeId;
            }
        }
        public string FirstName
        {
            get
            {
                return firstName;
            }
        }
        public string LastName
        {
            get
            {
                return lastName;
            }
        }
        public double BaseSalary
        {
            get
            {
                return baseSalary;
            }
        }
        public double GrossSales
        {
            get
            {
                return grossSales;
            }
            set
            {
                if (value > 0.00)
                    grossSales = value;
            }
        }
        public double CommissionRate
        {
            get
            {
                return commissionRate;
            }
            set
            {
                if (value > 0.1 & value < 1.0)
                    commissionRate = value;
            }
        }

        //constractors
        public BasePlusCommissionEmployee(int employeeId, string firstName, string lastName, 
                            double baseSalary, double grossSales, double commisssionRate)
        {
            this.employeeId = employeeId;

            if(firstName != "null")
            this.firstName = firstName;

            if(lastName != "null")
            this.lastName = lastName;

            if (baseSalary > 0.00)           
            this.baseSalary = baseSalary;
            
            GrossSales = grossSales;
            CommissionRate = commisssionRate;
        }
        public BasePlusCommissionEmployee(int employeeId, string firstName, double baseSalary)
        {
            this.employeeId = employeeId;
            this.firstName = firstName;
            this.baseSalary = baseSalary;
        }

        //methods:
        public double earning()
        {
            return (CommissionRate * GrossSales) / 100 + BaseSalary;
        }
        public override string ToString()
        {

            return string.Format("Employee ID:{0} \nFirst Name:{1} \nLast Name:{2} " +
                                    "\nBase Salary:{3:c} \nGross Sales:{4:c} \nCommision Rate:{5}", +
                               EmployeeID, FirstName, LastName, BaseSalary, GrossSales, CommissionRate);
        }




    }
}
