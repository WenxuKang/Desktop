﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise_01
{
    class BasePlusCommissionEmployeeTest
    {
        static void Main(string[] args)
        {
            BasePlusCommissionEmployee employee1 = new BasePlusCommissionEmployee(12345, "Xiaohui", "Hao",
                500.00, 1000.00, 0.7);                       
            Console.WriteLine(employee1.ToString());
            Console.WriteLine();

            double finalSalary = employee1.earning();
            Console.WriteLine("Final Salary:{0:c}", finalSalary);
            Console.WriteLine();

            BasePlusCommissionEmployee employee2 = new BasePlusCommissionEmployee(12346, "Liping", 800.00);
            Console.WriteLine(employee2.ToString());
            Console.WriteLine();
        }   

    }
}

