﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02
{
    class CheckingAccount
    {
        private int accountNumber;
        private string customerName;
        private double accountBalance;

        //properties
        public int AccountNumber
        {
            get
            {
                return accountNumber;
            }
        }
        public string CustomerName
        {
            get
            {
                return customerName;
            }
        }
        public double AccountBalance
        {
            get
            {
                return accountBalance;
            }
            set
            {
                if (value >= 50.00)
                    accountBalance = value;
            }
        }

        //constructor
        public CheckingAccount(int accountNumber, string customerName, double accountBalance)
        {
            this.accountNumber = accountNumber;
            this.customerName = customerName;
            AccountBalance = accountBalance;
        }

        //method
        public double withdraw()
        {
            double amount;
            double transactionFee = 3.00;
            Console.Write("Input Withdraw Amount: $");
            amount = Convert.ToDouble(Console.ReadLine());            
           
            if (amount < 0.00)
            {
                amount = 0.00;
                transactionFee = 0.00;
            }                
            return (AccountBalance - amount - transactionFee);

        }
        public override string ToString()
        {
            return string.Format("Account Number:{0} \nCustomer Name:{1} \nAccount Balance:{2:c}",
                AccountNumber, CustomerName, AccountBalance);
        }
    }
}
