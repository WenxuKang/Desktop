﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise01
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaration & Initialization
            //Twoday Object
            TwoDayPackage tp = new TwoDayPackage(01, "Giang Nguyen", "Scarborough, ON", 10, 0.1, 10);
            Console.WriteLine(tp.ToString());
            Console.WriteLine($"Cost: {tp.CaculatePackageCost()}\n");
            //OverNight Object
            OverNightPackage op = new OverNightPackage(02, "Fernando", "North York, ON", 10, 0.5, 10);
            Console.WriteLine(op.ToString());
            Console.WriteLine($"Cost: {op.CaculatePackageCost()}\n");
        }
    }
}
