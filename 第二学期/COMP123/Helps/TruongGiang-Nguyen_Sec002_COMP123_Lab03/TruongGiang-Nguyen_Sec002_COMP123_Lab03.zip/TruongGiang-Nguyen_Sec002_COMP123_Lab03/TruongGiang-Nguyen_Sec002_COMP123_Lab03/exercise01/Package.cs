﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise01
{
    abstract class Package // base class
    {
        //Declarations
        int packID;
        string senderName;
        string senderAdd;
        double weight;
        double ratePerGram;
        public Package() { } //Default Constructor
        public Package(int ID, string name, string address, double weight, double rate) //OverLoad Constructor
        {
            PackID = ID;
            SenderName = name;
            SenderAdd = address;
            Weight = weight;
            RatePerGram = rate;
        }
        //Properties
        public int PackID
        {
            get { return packID; }
            set { packID = value; }
        }
        public string SenderName
        {
            get { return senderName; }
            set { senderName = value; }
        }
        public string SenderAdd
        {
            get { return senderAdd; }
            set { senderAdd = value; }
        }
        public double Weight
        {
            get { return weight; }
            set
            {
                if (value > 0)
                    weight = value;
                else
                    weight = 0;
            }
        }
        public virtual double RatePerGram //Properties for later implement in Overnight Class
        {
            get { return ratePerGram; }
            set
            {
                if (value > 0)
                    ratePerGram = value;
                else
                    ratePerGram = 0;
            }
        }
        public abstract double CaculatePackageCost(); //Abstract method for later implement
        public override string ToString() //Override Object's Method ToString
        {
            return String.Format($"ID: {PackID}\nSender: {SenderName}\nAddress:{SenderAdd}\nRate: {RatePerGram}\nWeight: {Weight}");
        }
    }
}
