﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise01
{
    class TwoDayPackage : Package
    {
        //Declaration
        double adminCharges;
        //Constructor base on Package class
        public TwoDayPackage(int ID, string name, string address, double weight, double rate, double adminCharges) : base(ID, name, address, weight, rate)
        {
            AdminCharges = adminCharges;
        }
        //Properties
        public double AdminCharges
        {
            get { return adminCharges; }
            set
            {
                if (value > 0)
                    adminCharges = value;
                else
                    adminCharges = 0;
            }
        }
        //Implement CaculatePackageCost Method of Base class
        public override double CaculatePackageCost()
        {
            return Weight*RatePerGram+AdminCharges;
        }
        public override string ToString()
        {
            return base.ToString() + String.Format($"\nAdmin Charges: {AdminCharges}");
        }
    }
}
