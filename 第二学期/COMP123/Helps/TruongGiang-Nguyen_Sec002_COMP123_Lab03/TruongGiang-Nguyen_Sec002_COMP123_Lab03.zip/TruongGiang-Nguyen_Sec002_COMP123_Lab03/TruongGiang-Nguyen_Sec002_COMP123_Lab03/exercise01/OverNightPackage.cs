﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise01
{
    class OverNightPackage : Package
    {
        //Declarations
        double expressCharges;
        //Constructor base on Package class
        public OverNightPackage(int ID, string name, string address, double weight, double rate, double expressCharges) : base(ID, name, address, weight, rate)
        {
            ExpressCharges = expressCharges;
        }
        //Implement Property RatePerGram +10%
        public override double RatePerGram
        { get => base.RatePerGram*1.1; set => base.RatePerGram = value; }
        public double ExpressCharges
        {
            get { return expressCharges; }
            set
            {
                if (value > 0)
                    expressCharges = value;
                else
                    expressCharges = 0;
            }
        }
        //Override Abstract base method
        public override double CaculatePackageCost()
        {
            return RatePerGram*Weight+ExpressCharges;
        }
        public override string ToString()
        {
            return String.Format($"ID: {PackID}\nSender: {SenderName}\nAddress:{SenderAdd}\nOriginal Rate: {base.RatePerGram}\tFinal Rate(+10%): {RatePerGram}\nWeight: {Weight}\nExpress Charges: {ExpressCharges}");
        }
    }
}
