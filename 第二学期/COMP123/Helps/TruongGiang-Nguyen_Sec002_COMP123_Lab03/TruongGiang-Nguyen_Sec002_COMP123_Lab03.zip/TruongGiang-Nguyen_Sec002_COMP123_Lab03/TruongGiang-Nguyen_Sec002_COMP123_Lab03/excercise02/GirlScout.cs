﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace excercise02
{
    class GirlScout : Salesperson, ISellable
    {
        int numOfBoxes = 0;
        public GirlScout(string firstName, string lastName) : base(firstName, lastName)
        {
        }
       
        public int NumOfBoxes
        {
            get { return numOfBoxes; }
            set { numOfBoxes = value; }
        }

        public void MakeSale()
        {
            int cookiesBox;
            Console.WriteLine("\nEnter number of cookies boxes sold: ");
            cookiesBox = Convert.ToInt32(Console.ReadLine());
            NumOfBoxes = NumOfBoxes + cookiesBox;
        }

        public void SalesSpeech()
        {
            Console.WriteLine("\nThis is GirlScout!");
            Console.WriteLine(base.ToString() + String.Format($"\nNumber of Boxes Sold: {NumOfBoxes}"));
        }
    }
}
