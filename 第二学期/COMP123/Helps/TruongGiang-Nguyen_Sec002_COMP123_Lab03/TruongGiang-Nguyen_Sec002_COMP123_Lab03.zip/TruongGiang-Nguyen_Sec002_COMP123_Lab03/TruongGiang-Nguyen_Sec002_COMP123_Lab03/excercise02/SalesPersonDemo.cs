﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace excercise02
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaration
            GirlScout g1 = new GirlScout("Fernando", "Martin");
            g1.SalesSpeech();
            g1.MakeSale();
            Console.WriteLine("------After-------");
            g1.SalesSpeech();
            g1.MakeSale();
            g1.SalesSpeech();
            RealEstateSalesperson r1 = new RealEstateSalesperson("Truong", "Nguyen", 0.05);
            r1.SalesSpeech();
            r1.MakeSale();
            Console.WriteLine("------After-------");
            r1.SalesSpeech();
            r1.MakeSale();
            r1.SalesSpeech();
        }
    }
}
