﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace excercise02
{
    class RealEstateSalesperson : Salesperson, ISellable // Inheritence 
    {
        //Declaration & Initialization
        double totalAmount = 0;
        double totalComm = 0;
        double commRate;
        public RealEstateSalesperson(string firstName, string lastName, double commRate):base(firstName, lastName)
        {
            CommRate = commRate;
        }
        public double TotalAmount
        {
            get { return totalAmount; }
            set { totalAmount = value; }
        }
        public double TotalComm
        {
            get { return totalComm; }
            set { totalComm = value; }
            
        }
        public double CommRate
        {
            get { return commRate; }
            set
            {
                if (value > 0)
                    commRate = value;
                else
                    commRate = 0;
            }
        }

        public void MakeSale()
        {
            int iNum;
            Console.WriteLine("\nEnter the value of the house: ");
            iNum = Convert.ToInt32(Console.ReadLine());
            TotalAmount = TotalAmount + iNum;
            TotalComm = TotalAmount * CommRate;
        }

        public void SalesSpeech()
        {
            Console.WriteLine("\nThis is RealEstate!");
            Console.WriteLine(base.ToString() + String.Format($"\nCommission Rate: {CommRate}\nTotal Amount Sold: {TotalAmount}\nTotal Comm Earned: {TotalComm}"));
        }
        
    }
}
