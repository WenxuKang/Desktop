﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    class Student//Used to store the entered data
    {
        public int idUsername { get; set;}
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public double grade { get; set; }

    }
}
