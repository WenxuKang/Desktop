const questions = [];
for(let i=0; i<1000; i++){
    let a = Math.floor(Math.random()*100);
    let b = Math.floor(Math.random()*100);
    let c = a + b;
    questions.push({
        "topic":`Which is the correct answer of ${a} + ${b} = ?`,
        "answers":[
            c,
            c+1,
            c-1,
            c*10
        ],
        "correct": c
    })
}



const Counter = {
    num:120,
    game:null,
    elem: document.querySelector("#counter"),
    handler:null,
    init: function(num, Game){
        this.num = num;
        this.game = Game;
        return this;
    },
    clear: function(){
        if(this.handler){
            clearTimeout(this.handler);
        }
    },
    start: function(){
        this.checkTime();
        this.elem.innerText = this.num;
        this.num -=1;
        if(this.num<0){
            return;
        }
        this.handler = setTimeout(function(){
            Counter.start();
        }, 1000);
    },
    checkTime: function(){
        const roundName = document.querySelector("#roundName");
        if(this.game.current_round =="round1"){
            if(this.num<=0){
                this.game.current_round = "round2";
                roundName.innerText = "Round 2";
                document.querySelector("#round1").style.display="none";
                document.querySelector("#round2").style.display="block";
                let index = this.game.getNewQuestionIndex();
                this.game.current_question = questions[index];
                this.game.showQuestion();
                this.game.updateLevel();
                this.num = 90;
            }else{
                if(this.game.bank>=500000){
                    this.num = 90;
                }
            }
        }else if(this.game.current_round =="round2"){
            if(this.num<=0){
                this.game.current_round = "round3";
                roundName.innerText = "Round 3";
                document.querySelector("#round1").style.display="none";
                document.querySelector("#round2").style.display="none";
                let index = this.game.getNewQuestionIndex();
                this.game.current_question = questions[index];
                this.game.showQuestion();
                this.game.updateLevel();
                this.num = 60;
            }else{
                if(this.game.bank>=500000){
                    this.num = 60;
                }
            }
        }else{
            if(this.num<=0){
                clearTimeout(this.handler);
                if(Game.number>0){
                    document.querySelector("#question").style.display="none";
                    document.querySelector("#title").style.display="none";
                    document.querySelector("#bankDiv").style.display="none";
                    document.querySelector("#result").style.display="block";
                    document.querySelector("#resultContent").innerText = "Opps, you are the weakest link !";
                }
            }else{
                if(Game.number<=0){
                    document.querySelector("#question").style.display="none";
                    document.querySelector("#title").style.display="none";
                    document.querySelector("#bankDiv").style.display="none";
                    document.querySelector("#result").style.display="block";
                    document.querySelector("#resultContent").innerText = `Congratulations! You have won ${Game.bank} $ !`;
                }
            }
        }
    }
}

const Game = {
    asked_questions: [],
    round1:{
        money_tree:[0, 1000, 5000, 100000, 50000, 75000, 125000, 250000, 500000],
        level: 0
    },
    round2:{
        money_tree:[0, 1000,10000, 75000, 125000, 500000],
        level: 0 
    },
    current_round: "round1",
    bank: 0, 
    current_question: {},
    number: 5,
    getNewQuestionIndex: function(){
        while(true){
            let index = Math.random()*questions.length;
            index = Math.floor(index);
            if(this.asked_questions.indexOf(index)==-1){
                return index;
            }
        }
    },
    showQuestion: function(){
        const { topic, answers } = this.current_question;
        document.querySelector("#topic").innerText = topic;
        this.shuffle(answers);
        document.querySelector("#a").innerText = answers[0];
        document.querySelector("#b").innerText = answers[1];
        document.querySelector("#c").innerText = answers[2];
        document.querySelector("#d").innerText = answers[3];
    },  

    start: function(){
        let index = this.getNewQuestionIndex();
        this.current_question = questions[index];
        this.showQuestion();
        this.updateLevel();
        return this;
    },
    shuffle: function(lst){
        for(let i=0; i<lst.length; i++){
            let j = Math.floor(Math.random()*lst.length);
            if(i!=j){
                let temp = lst[i];
                lst[i] = lst[j];
                lst[j] = temp;
            }
        }
    },
    bindEvents: function(){
        const elemA = document.querySelector("#a");
        elemA.addEventListener("click",function(){
            const ans = elemA.innerText; 
            Game.answer(ans);
        });
        const elemB = document.querySelector("#b");
        elemB.addEventListener("click",function(){
            const ans = elemB.innerText; 
            Game.answer(ans);
        });
        const elemC = document.querySelector("#c");
        elemC.addEventListener("click",function(){
            const ans = elemC.innerText; 
            Game.answer(ans);
        });
        const elemD = document.querySelector("#d");
        elemD.addEventListener("click",function(){
            const ans = elemD.innerText; 
            Game.answer(ans);
        });

        const bank = document.querySelector("#bank");
        const amount = document.querySelector("#amount");
        const roundName = document.querySelector("#roundName");
        bank.addEventListener("click",function(){
            console.log(Game.current_round)
            if(Game.current_round == "round1"){
                Game.bank += Game.round1.money_tree[Game.round1.level];
                Game.round1.level = 0;
                if(Game.bank>=500000){
                    Game.bank = 500000;
                    Game.current_round = "round2";
                    roundName.innerText = "Round 2";
                    document.querySelector("#round1").style.display="none";
                    document.querySelector("#round2").style.display="block";
                }
                Game.updateLevel();
            }else if(Game.current_round=="round2"){
                Game.bank += Game.round2.money_tree[Game.round2.level];
                Game.round2.level = 0;
                if(Game.bank>=1000000){
                    Game.bank = 1000000;
                    Game.current_round = "round3";
                    roundName.innerText = "Round 3";
                    document.querySelector("#round1").style.display="none";
                    document.querySelector("#round2").style.display="none";
                }
                Game.updateLevel();
            }
            amount.innerText = Game.bank;
        });
    },
    answer: function(ans){
        if(this.isCorrect(ans, this.current_question)){
            if(this.current_round == "round1"){
                this.round1.level +=1;
                if(this.round1.level>=this.round1.money_tree.length-1){
                    this.round1.level = this.round1.money_tree.length-1;
                }
            }else if(this.current_round == "round2"){
                this.round2.level +=1;
                if(this.round2.level>=this.round2.money_tree.length-1){
                    this.round2.level = this.round2.money_tree.length-1;
                }
            }else{
                this.number-=1;
                if(this.number == 0){
                    document.querySelector("#question").style.display="none";
                    document.querySelector("#title").style.display="none";
                    document.querySelector("#bankDiv").style.display="none";
                    document.querySelector("#result").style.display="block";
                    document.querySelector("#resultContent").innerText = `Congratulations! You have won ${Game.bank} $ !`;
                }
            }
            this.updateLevel();
            let index = this.getNewQuestionIndex();
            this.current_question = questions[index];
            this.showQuestion();
        }else{
            if(this.current_round == "round1"){
                this.round1.level = 0;
                this.updateLevel();
                let index = this.getNewQuestionIndex();
                this.current_question = questions[index];
                this.showQuestion();
            }else if(this.current_round == "round2"){
                this.round2.level = 0;
                this.updateLevel();
                let index = this.getNewQuestionIndex();
                this.current_question = questions[index];
                this.showQuestion();
            }else{
                document.querySelector("#question").style.display="none";
                document.querySelector("#title").style.display="none";
                document.querySelector("#bankDiv").style.display="none";
                document.querySelector("#result").style.display="block";
                document.querySelector("#resultContent").innerText = "Opps, you are the weakest link !";
            }

        }
       
    },
    isCorrect: function(ans, question){
        if(question.correct == ans){
            return true;
        }
        return false;
    },
    updateLevel: function(){
        if(this.current_round == "round1"){
            const { money_tree, level } = this.round1;
            const levels = document.querySelectorAll("#round1 > p");
            for(let i=0; i<levels.length; i++){
                if(i==levels.length-level-1){
                    levels[i].classList.add("active");
                }else{
                    levels[i].classList.remove("active");
                }
            }
        }

        if(this.current_round == "round2"){
            const { money_tree, level } = this.round2;
            const levels = document.querySelectorAll("#round2 > p");
            for(let i=0; i<levels.length; i++){
                if(i==levels.length-level-1){
                    levels[i].classList.add("active");
                }else{
                    levels[i].classList.remove("active");
                }
            }
        }
    }
}


Game.start().bindEvents();
Counter.init(120, Game).start();