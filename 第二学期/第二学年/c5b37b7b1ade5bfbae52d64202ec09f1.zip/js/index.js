const rule= document.querySelector("#rule");
const rules = document.querySelector("#rules");
const start= document.querySelector("#start");
const info= document.querySelector("#info");
const submit= document.querySelector("#submit");
rule.addEventListener("click",function(){
    rules.style.display="inline-block";
    setTimeout(function(){
        rules.style.display="none";
    }, 10000)
});

start.addEventListener("click",function(){
    rules.style.display="none";
    info.style.display="block";
});


submit.addEventListener("click",function(e){
    e.preventDefault();
    const name = document.form.name.value;
    const age = document.form.age.value;
    if(name==""){
        alert("name is empty");
        return;
    }
    if(age == ""){
        alert("age is empty");
        return;
    }
    location.href ="game.html?name="+name+"&age="+age;
});
