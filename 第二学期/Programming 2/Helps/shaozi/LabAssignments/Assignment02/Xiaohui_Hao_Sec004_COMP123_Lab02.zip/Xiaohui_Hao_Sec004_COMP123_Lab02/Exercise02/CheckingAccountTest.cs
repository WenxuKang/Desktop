﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02
{
    class CheckingAccountTest
    {
        static void Main(string[] args)
        {
            CheckingAccount customer1 = new CheckingAccount(12345, "Xiaohui Hao", 5000.00);
            Console.WriteLine(customer1.ToString());
            Console.WriteLine();

            double newBalance = customer1.withdraw();
            Console.WriteLine("New Balance:{0:c}", newBalance);
            Console.WriteLine();

            CheckingAccount customer2 = new CheckingAccount(12346, "Agnes Fang", 30.00);
            Console.WriteLine(customer2.ToString());
            Console.WriteLine();
        }
    }
}
