// variables initialization, the initial time interval is 0.2 second
var num = 2000;
var score = 0;
var timmer;
var bugImg;
// constant function will keep updating the bug position
window.onload = function start() {
    bugImg = document.getElementById("bug");
    bugImg.addEventListener("click", getBug, false);
    update();
}

function update() {
    document.getElementById('scoreband').innerHTML = score;
    timmer = window.setInterval(hopBug, num);
}

function hopBug() {
    bugImg.style.left = Math.random() * 800 + "px";
    bugImg.style.top = Math.random() * 400 + "px";
    bugImg.addEventListener("click", getBug, false);
}


//the bug caught method which can be used to display the bug caught event and
//reduce the time interval
function getBug() {

    bugImg.removeEventListener("click", getBug, false);
    bugImg.style.left = Math.random() * 800 + "px";
    bugImg.style.top = Math.random() * 400 + "px";

    score = score + 10;
    document.getElementById('scoreband').innerHTML = score;
    num = num - 200;
    clearInterval(timmer);
    timmer = window.setInterval(hopBug, num);
    alert(" Wow! you caught the bug!!");


}
//The reset method which will be used to reset the score of the current game
function resetScore() {
    score = 0;
    document.getElementById('scoreband').innerHTML = score;
    alert("You reset the score!!");
}
//the reset speed method which will be used to reset the current game time interval to the initial time rate
function resetSpeed() {
    num = 2000
    clearInterval(timmer);
    timmer = window.setInterval(hopBug, num);
    alert("You reset the speed!!");
}